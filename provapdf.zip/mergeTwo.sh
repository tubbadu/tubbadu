#!/usr/bin/bash

first=$2
second=$3
out=$1
title=$(basename -s .pdf $2)

pages=$(gs -dNODISPLAY -dNOSAFER -q -c "($first) (r) file runpdfbegin pdfpagecount = quit")
pages=$((pages+1))
pdfmark="[/Title ($title) /Page $pages /OUT pdfmark"
gs -q -dBATCH -dNOPAUSE -sDEVICE=pdfwrite -sOutputFile=$out $first $second <(echo "$pdfmark")
