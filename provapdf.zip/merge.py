#!/usr/bin/python3

import sys, os, subprocess

mergeTwo = "'/home/tubbadu/Scaricati/provapdf/mergeTwo.sh'"

def bash(cmd, read=False):
	print(cmd)
	if read:
		try:
			x = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			x = False
		return x
	else:
		os.system(cmd)
		return 

arg = list(sys.argv[1:])

if len(arg) < 3:
    print("parameter error")
    exit()

bash(f"{mergeTwo} '{arg[0]}' '{arg[1]}' '{arg[2]}'")
for f in arg[3:]:
    bash(f"{mergeTwo} '{arg[0]}' '{arg[0]}' '{f}'")